﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.UI;

namespace Texts
{
	public class TextContainer : MonoBehaviour
	{
		public string text = "";
	}

	public class Names
	{
		public static string tCacao = "Cacao";
		public static string tSugar = "Sugar";
		public static string tMilk = "Milk";
		public static string tButter = "Butter";
		public static string tCream = "Cream";
	}
}
